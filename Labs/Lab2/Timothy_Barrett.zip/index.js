const geometry = require("./geometry");
const utilities = require("./utilities");

//Geometry
console.log("***Geometry***");
console.log("**volumeOfRectangularPrism");
console.log(geometry.volumeOfRectangularPrism(3, 8, 9)); 
console.log(geometry.volumeOfRectangularPrism(2, -3, 4)); 
console.log(geometry.volumeOfRectangularPrism(2, "hello", 4));
console.log("**surfaceAreaOfRectangularPrism");
console.log(geometry.surfaceAreaOfRectangularPrism(5,4,10)); 
console.log(geometry.surfaceAreaOfRectangularPrism(5,4,-10)); 
console.log(geometry.surfaceAreaOfRectangularPrism(5,null,10)); 
console.log("**volumeOfSphere");
console.log(geometry.volumeOfSphere(5)); 
console.log(geometry.volumeOfSphere(-5)); 
console.log(geometry.volumeOfSphere(null)); 
console.log("**surfaceAreaOfSphere");
console.log(geometry.surfaceAreaOfSphere(2)); 
console.log(geometry.surfaceAreaOfSphere(-2)); 
console.log(geometry.surfaceAreaOfSphere(null)); 

//Utilities
console.log("***Utilities***:");

console.log("**deepEquality");
const first = {a: 2, b: 3};
const second = {a: 2, b: 4};
const third = {a: 2, b: 3};
console.log(utilities.deepEquality(first, second)); // false
console.log(utilities.deepEquality(first, third)); // true
console.log(utilities.deepEquality(3, "a"));

console.log("**uniqueElements");
const testArr = ["a", "a", "b", "a", "b", "c"];
console.log(utilities.uniqueElements(testArr)); // outputs 3
const testArr2 = [];
console.log(utilities.uniqueElements(testArr2));
const testArr3 = "Hello";
console.log(utilities.uniqueElements(testArr3));
console.log("**countOfEachCharacterInString");
console.log(utilities.countOfEachCharacterInString("Hello"));
console.log(utilities.countOfEachCharacterInString("abc123"));
console.log(utilities.countOfEachCharacterInString("Testing testing 123 hello"));
console.log(utilities.countOfEachCharacterInString(""));
console.log(utilities.countOfEachCharacterInString(null));