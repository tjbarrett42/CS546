const palindromeData = require("./palindrome");
//const userData = require("./users");

module.exports = {
	//users: userData,
  pStr: palindromeData
};