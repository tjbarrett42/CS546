const recipeData = require("./recipes");
//const userData = require("./users");

module.exports = {
	//users: userData,
  recipes: recipeData
  
};